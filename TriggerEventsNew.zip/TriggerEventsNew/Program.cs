﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Messaging.EventHubs;
using Azure.Messaging.EventHubs.Producer;
using Newtonsoft.Json;

namespace TriggerEventsNew
{
    class Program
    {
        static async Task Main()
        {
            //-----------------------------------------------------------
            //set all values here

            string connectionString = "Endpoint=sb://dhevpowerbistreaming.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=p7BF1X7y03i+reLsBAnXZpyPV6IUyX8d8dUVBUADlQA=";
            string eventHubNameWebVisits = "dhevpowerbisimple";

            DateTime dateValue = DateTime.Parse("2021-08-01 09:00:00");
            int dateloopcounter = 1; //how many days to loop

            //for each day, how many "blocks" of messages will be sent - randomly generated value within min/max
            int minimumdailysessionblocks = 3;
            int maximumdailysessionblocks = 6;

            //for each block of messages in each day, how many messages will be sent in each block - randomly generated value within min/max
            int minimumdailymessagesperblock = 10;
            int maximumdailymessagesperblock = 20;

            

            //----------------------------------------------------------
            //system set message count variable - do not amend
            int messagescount = 0;

            for (int dateloop = 0; dateloop < dateloopcounter; dateloop++)
            {
                //set number of message blocks to send per day
                Random rnd3 = new Random();
                int sessionloop = rnd3.Next(minimumdailysessionblocks, maximumdailysessionblocks);

                for (int loops = 0; loops < sessionloop; loops++)
                {
                    //set number of messages to be sent in the current block
                    Random rndproductvisit = new Random();
                    int productvisit = rndproductvisit.Next(1, 50);

                    for (int loopsproduct = 0; loopsproduct < productvisit; loopsproduct++)
                    {

                        //DateTime eventdatetime2 = DateTime.Now;
                        Random rnduserid = new Random();
                        int userid = rnduserid.Next(5000, 5100);

                        Random rndproductnumber = new Random();
                        int productnumber = rndproductnumber.Next(700, 999);

                        Random rndpageviewlength = new Random();
                        int pageviewlength = rndpageviewlength.Next(minimumdailymessagesperblock, maximumdailymessagesperblock);

                        Random rnd = new Random();

                        String device;

                        int devicetype = rnd.Next(1, 4);

                        if (devicetype == 1)
                        {
                            device = "mobile";
                        }
                        else if (devicetype == 2)
                        {
                            device = "tablet";
                        }
                        else
                        {
                            device = "pc";
                        }

                         Random rndeventtype = new Random();

                        String eventtype;

                        int eventtypenum = rnd.Next(1, 10);

                        if (eventtypenum <= 8)
                        {
                            eventtype = "browseproduct";
                        }
                        else
                        {
                            eventtype = "putinbasket";
                        }

                        ProductVisitMessage productbrowsemessage = new ProductVisitMessage
                        {
                            UserID = userid,
                            EventType = eventtype,
                            EventDateTime = dateValue,
                            ProductID = Int32.Parse(productnumber.ToString()),
                            URL = "/product/" + productnumber.ToString(),
                            Device = device,
                            SessionViewSeconds = pageviewlength
                        };

                        //dateincrement = dateincrement.AddSeconds(15);

                        string outputproductbrowsemessage = JsonConvert.SerializeObject(productbrowsemessage);

                        Random rnd4 = new Random();

                        int messagdelay = rnd4.Next(1000, 2000);
                        ;

                        await using (var producerClient = new EventHubProducerClient(connectionString, eventHubNameWebVisits))
                        {
                            using EventDataBatch eventBatch = await producerClient.CreateBatchAsync();

                            eventBatch.TryAdd(new EventData(Encoding.UTF8.GetBytes(outputproductbrowsemessage)));

                            await producerClient.SendAsync(eventBatch);

                        }

                        Console.WriteLine(outputproductbrowsemessage);

                        messagescount++;

                         }

                    dateValue = dateValue.AddSeconds(5);
                }

                //Add 1 day to the current date to generate the next day of data
                dateValue = dateValue.AddDays(1);
            }

            Console.WriteLine("Loop Completed, Messages sent: " + messagescount.ToString());

        }
    }

     public class ProductVisitMessage
    {
        public int UserID { get; set; }
        public string EventType { get; set; }
        public DateTime EventDateTime { get; set; }
        public int ProductID { get; set; }
        public string URL { get; set; }
        public string Device { get; set; }
        public int SessionViewSeconds { get; set; }
    }
}
